<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="index, follow">
    <meta name="author" content="Anar.N.Agaev - anar.n.agaev@gmail.com">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/template_styles.css" />
	<link rel="stylesheet" type="text/css" href="style/styles.css" />
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
	
	
	<!--[if lt IE 9]>
	 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
</head>
<body>

	<?include_once("template/header.php");?>
	
	<h1>Контакты</h1>
	<h3>Мы всегда внимательны к сообщениям со страницы контакты</h3>
	<form action="" method="post" enctype="multipart/form-data" id="feedback">
		<label for="nameFeedback">Ваше имя</label><input type="text" id="nameFeedback">
		<label for="mailFeedback">Электронная почта</label><input type="text" id="mailFeedback">
		<label for="phoneFeedback">Телефон</label><input type="text" id="phoneFeedback">
		<label for="contentFeedback">Ваш вопрос или предложение</label><textarea id="contentFeedback"></textarea>
		<div class="buttonMiddle btnRoundBorder btnFeedback" id="feedbackSubmit">отправить</div>
		<span>
			Нажимая кнопку «Отправить», Вы даёте согласие<br>на
			<a href="/obrabotka-personalnyh-dannyh.php" target="_blank">обработку персональных данных</a>.
		</span>
	</form>	
	
	
	<?include_once("template/footer.php");?>

</body>
</html>