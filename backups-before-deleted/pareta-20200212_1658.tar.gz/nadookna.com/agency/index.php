<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="index, follow">
    <meta name="author" content="Anar.N.Agaev - anar.n.agaev@gmail.com">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/template_styles.css" />
	<link rel="stylesheet" type="text/css" href="style/styles.css" />
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
	
	
	<!--[if lt IE 9]>
	 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
</head>
<body>

	<?include_once("template/header.php");?>

	<div class="indexPageContent">
		<img class="biglogo" src="/img/biglogo.png">
		<div class="mainPageСaption">
			<span class="mainPage-description-border">
				&nbsp;design
				<span class="mainPage-description-border-frame"></span>
				<span class="mainPage-description-border-leftTop"></span>
				<span class="mainPage-description-border-top"></span>
				<span class="mainPage-description-border-rightTop"></span>
				<span class="mainPage-description-border-leftBottom"></span>
				<span class="mainPage-description-border-bottom"></span>
				<span class="mainPage-description-border-rightBottom"></span>
			</span>
			<span class="mainPage-description-plus">&nbsp;+</span> &lt;front-end/&gt;
			<br><font>development</font>
		</div>
		
		<h2>Мы</h2>
		<p>
			молодая креативная команда дизайнеров и разработчиков. 
			Проектируем и создаём в вебе всё от лендинга и сайта-визитки до интрнет магазина 
			и портала + контекстная реклама.
		</p>
		<h2>Наши клиенты</h2>
		<p>
			амбициозные предприниматели, желающие получать лучшее.
		</p>
		<h2>Мы используем</h2>
		<p>
			Sketch, Photoshop, PHP7, СSS3, HTML5, JavaScript, JQuery, MySql и другие 
			веб технологии. Срочные сайты запускаем на Wordpress и Битрикс.
		</p>
		
		<h2>Наши продукты</h2>
		<p>
			<a href="">Лендинг + контекст</a>, 
			<a class="unactive" href="">посадочные страницы</a>, 
			<a class="unactive" href="">сайты визитки</a>,
			<a class="unactive" href="">корпоративные сайты</a>,
			<a class="unactive" href="">интернет-витрины</a>,
			<a class="unactive" href="">интернет-магазины</a>,
			<a class="unactive" href="">промо-сайты</a>,
			<a class="unactive" href="">блоги</a>,
			<a class="unactive" href="">форумы</a>,
			<a class="unactive" href="">контекстная реклама</a> и
			<a class="unactive" href="">веб дизайн</a>
		</p>
	</div>
	
	
	<?include_once("template/footer.php");?>

</body>
</html>