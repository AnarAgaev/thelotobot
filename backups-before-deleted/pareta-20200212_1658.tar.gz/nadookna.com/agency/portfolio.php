<!DOCTYPE HTML>
<html>
<head>
	<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
    <meta name="robots" content="index, follow">
    <meta name="author" content="Anar.N.Agaev - anar.n.agaev@gmail.com">
    <meta name="description" content="">
    <meta name="keywords" content="">
    <meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
	<title></title>
	<link rel="stylesheet" type="text/css" href="style/template_styles.css" />
	<link rel="stylesheet" type="text/css" href="style/styles.css" />
	<link rel="shortcut icon" href="img/favicon.ico" type="image/x-icon" />
	
	<!--[if lt IE 9]>
	 <script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script>
	<![endif]-->
	
	<script src="https://ajax.googleapis.com/ajax/libs/jquery/1.12.2/jquery.min.js"></script>
</head>
<body>

	<?include_once("template/header.php");?>
	<h1>Портфолио</h1>
	<h3>Наши проекты и клиенты.<br>Несколько работ в хронологическом порядке.</h3>
	<div class="portfolioItems clearfix">
		<div id="pi__1" style="background: #0033FF"><span></span><p>Название проекта</p></div>
		<div id="pi__2" style="background: #009933"><span></span><p>Название проекта</p></div>
		<div id="pi__3" style="background: #FF3333"><span></span><p>Название проекта</p></div>
		<div id="pi__4" style="background: #A0522D"><span></span><p>Название проекта</p></div>
		<div id="pi__5" style="background: #FFCC00"><span></span><p>Название проекта</p></div>
	</div>
	<?include_once("template/footer.php");?>

</body>
</html>