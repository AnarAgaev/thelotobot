<meta http-equiv="Content-Type" content="text/html; charset=utf-8"/>
<meta name="robots" content="index, follow">
<meta name="viewport" content="width=device-width, initial-scale=1.0, maximum-scale=1.0, user-scalable=0">
<? require_once SITE__DIR.'template/favicon.php'; ?>
<? require_once SITE__DIR.'template/fonts.php'; ?>
<link rel="stylesheet" type="text/css" href="/style/style.min.css" />
<!--[if lt IE 9]><script src="http://html5shim.googlecode.com/svn/trunk/html5.js"></script><![endif]-->