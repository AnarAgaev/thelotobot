<div class="popup__message" id="error__nums">
	<p><?= $CONTENT__DATA__ALL_PAGE['NUMBERS_INCORRECT']; ?></p>
	<button id="err__nums"><?= $CONTENT__DATA__ALL_PAGE['CHANGE_NUMBERS']; ?></button>
</div>
<div class="popup__message" id="send__mail__true">
	<p><?= $CONTENT__DATA__ALL_PAGE['CHECK_SENT']; ?></p>
	<button id="send__ticket__to__mail"><?= $CONTENT__DATA__ALL_PAGE['CLOSE']; ?></button>
</div>
<div class="popup__message" id="send__mail__error">
	<p><?= $CONTENT__DATA__ALL_PAGE['SEND_TICKET_ERROR']; ?></p>
	<button id="send__ticket__to__mail"><?= $CONTENT__DATA__ALL_PAGE['CLOSE']; ?></button>
</div>
<div class="popup__message" id="error__add__ticket">
	<p><?= $CONTENT__DATA__ALL_PAGE['TICKET_ADD_ERROR']; ?></p>
	<button id="send__ticket__to__mail"><?= $CONTENT__DATA__ALL_PAGE['CLOSE']; ?></button>
</div>